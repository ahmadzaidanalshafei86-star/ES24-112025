/* 1 carousel */
$('#carousel-1').carousel({
      interval: 4000,
      wrap: true,
      keyboard: true,
     autoplay:false

 });
 
 
 /* 2 carousel */
 $('#carousel-2').carousel({
      interval: 6000,
      wrap: true,
      keyboard: true,
      interval: false
 });
 
 
 /* 3 carousel */
 $('#carousel-3').carousel({
     interval: 8000,
     wrap: true,
     keyboard: true,
     interval: false
 });

 /* 4 carousel example with jumbotron */
 $('#carousel-4').carousel({
     interval: 10000,
     wrap: true,
     keyboard: true,
     interval: false
 });

 /* 5 carousel example */
 $('#carousel-5').carousel({
     interval: 6000,
     wrap: true,
     keyboard: true,
     interval: false
 });

 /* 6 carousel example */
 $('#carousel-6').carousel({
     interval: 8000,
     wrap: true,
     keyboard: true,
     interval: false
 });

 /* 7 carousel example */
 $('#carousel-7').carousel({
     interval: 4000,
     wrap: true,
     keyboard: true,
     interval: false
 });

 /* 8 carousel example */
 $('#carousel-8').carousel({
     interval: 6000,
     wrap: true,
     keyboard: true,
     interval: false
 });

 /* 9 carousel example */
 $('#carousel-9').carousel({
     interval: 8000,
     wrap: true,
     keyboard: true,
     interval: false
 });

 /* 10 carousel example */
 $('#carousel-10').carousel({
     interval: 2000,
     wrap: true,
     keyboard: true,
     interval: false
 });

 /* 11 carousel example */
 $('#carousel-11').carousel({
     interval: 4000,
     wrap: true,
     keyboard: true,
     interval: false
 });

 /* 12 carousel example */
 $('#carousel-12').carousel({
     interval: 6000,
     wrap: true,
     keyboard: true,
     interval: false
 });

 /* 13 carousel example */
 $('#carousel-13').carousel({
     interval: 8000,
     wrap: true,
     keyboard: true,
     interval: false
 });
 
 /* 14 carousel example */
 $('#carousel-14').carousel({
     interval: 8000,
     wrap: true,
     keyboard: true,
     interval: false
 });